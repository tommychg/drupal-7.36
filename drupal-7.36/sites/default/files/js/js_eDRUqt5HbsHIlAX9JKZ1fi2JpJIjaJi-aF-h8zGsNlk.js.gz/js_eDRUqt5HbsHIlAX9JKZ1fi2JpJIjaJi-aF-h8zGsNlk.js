Drupal.locale = { 'strings': {"":{"Configure":"\u8a2d\u7f6e"}} };;
