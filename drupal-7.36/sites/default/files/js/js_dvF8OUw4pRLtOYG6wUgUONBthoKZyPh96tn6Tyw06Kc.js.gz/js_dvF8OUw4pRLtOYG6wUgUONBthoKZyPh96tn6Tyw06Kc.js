Drupal.locale = { 'pluralFormula': function ($n) { return Number(($n>1)); }, 'strings': {"":{"Configure":"\u8a2d\u7f6e","Show":"\u986f\u793a","Enabled":"\u555f\u7528","Edit":"\u7de8\u8f2f","Select all rows in this table":"\u9078\u53d6\u8868\u683c\u4e2d\u7684\u6240\u6709\u5217","Deselect all rows in this table":"\u53d6\u6d88\u9078\u53d6\u8868\u683c\u4e2d\u7684\u6240\u6709\u5217","Done":"\u5b8c\u6210","Disabled":"\u505c\u7528","Not published":"\u672a\u767c\u8868","Please wait...":"\u8acb\u7a0d\u7b49..."}} };;
(function ($) {

Drupal.behaviors.textarea = {
  attach: function (context, settings) {
    $('.form-textarea-wrapper.resizable', context).once('textarea', function () {
      var staticOffset = null;
      var textarea = $(this).addClass('resizable-textarea').find('textarea');
      var grippie = $('<div class="grippie"></div>').mousedown(startDrag);

      grippie.insertAfter(textarea);

      function startDrag(e) {
        staticOffset = textarea.height() - e.pageY;
        textarea.css('opacity', 0.25);
        $(document).mousemove(performDrag).mouseup(endDrag);
        return false;
      }

      function performDrag(e) {
        textarea.height(Math.max(32, staticOffset + e.pageY) + 'px');
        return false;
      }

      function endDrag(e) {
        $(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag);
        textarea.css('opacity', 1);
      }
    });
  }
};

})(jQuery);
;
